package com.capgemini.mypackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String userName= request.getParameter("userName");
		String[]  courseName=request.getParameterValues("courseName");
		String first= request.getParameter("first");
		String second= request.getParameter("second");
		String operation= request.getParameter("operation");
		int a1= Integer.parseInt(first);
		int a2= Integer.parseInt(second);
		
		out.println("Welcome "+ userName);
		
		
		for(Object o: courseName)
			out.println(o);
		
		if("add".equals(operation)){
			out.println("Sum is "+(a1+a2));
		}
		else if("subtract".equals(operation)){
			out.println("Difference is "+(a1-a2));
		}
		else if("multiply".equals(operation)){
			out.println("Multiplication is "+(a1*a2));
		}
		else
			out.println("Division is "+(a1/a2));
	
		
		
		Enumeration en=request.getParameterNames();
		 
		while(en.hasMoreElements())
		{
			Object objOri=en.nextElement();
			String param=(String)objOri;
			String value=request.getParameter(param);
			out.println("Parameter Name is '"+param+"' and Parameter Value is '"+value+"'");
		}		
			out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
