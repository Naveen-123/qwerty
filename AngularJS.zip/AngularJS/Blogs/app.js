/**
 * Created by navsinha on 13-Jun-16.
 */

var helloApp = angular.module('helloApp',[]);