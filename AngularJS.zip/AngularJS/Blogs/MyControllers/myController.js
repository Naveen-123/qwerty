/**
 * Created by navsinha on 13-Jun-16.
 */

var blogController;
blogController = helloApp.controller('blogController', function ($scope) {
    $scope.sortorder = '';
    $scope.blogs = [
        {
            title: "Playing It My Way.",
            author: "Sachin Tendulkar",
            date: new Date('11/05/2014'),
            description: "Playing It My Way is the autobiography of former Indian cricketer Sachin Tendulkar. It was launched on 5 November 2014 in Mumbai. The book summarises Tendulkar's early days, his 24 years of international career and aspects of his life that have not been shared publicly. It entered the Limca Book of Records for being the best selling adult hardback across both fiction and non-fiction categories. In India, it broke the record set by Walter Isaacson's biography of Steve Jobs for being the most pre-ordered biographical book.",
            image: "../image/Playingitmywaybookcover.jpeg",
            voteCount: 500
        },
        {
            title: "MSD: The Man, The Leader.",
            author: "Mahendra Singh Dhoni",
            date: new Date('12/06/2014'),
            description: "MSD: The Man, the Leader unveils Dhoni’s struggles during his growing-up years, analyses his career as a cricketer and captain par excellence, and reveals his innate leadership abilities by speaking to luminaries from different walks of life including Harsh Goenka, Vineet Nayar and Dhanraj Pillay in a jargon-free, easy-to-read style. Replete with examples of Dhoni’s strong personality and inspiring leadership, and marking one decade of his entry into the Indian cricket team, MSD: The Man, the Leader will reinforce the belief: Yes, I CAN.",
            image: "../image/51vfS6WI8jL._SX324_BO1,204,203,200_.jpg",
            voteCount: 370
        },
        {
            title: "Being Freddie: My Story So Far.",
            author: "Andrew Flintoff",
            date: new Date('10/09/2015'),
            description: "Andrew made his first class debut for Lancashire in 1995, and international honours came when he made his Test Match debut in 1998 vs South Africa. His One Day International debut followed in 1999 vs Pakistan. Andrew made his biggest impact for England in the summer of 2005, when he played a major role in regaining the Ashes from Australia. His contributions won him the BBC Sports Personality of the Year award in the same year. In 2006 Andrew was awarded an MBE, yet in September 2010, as one of the biggest players in the game, Flintoff retired from professional cricket due to a recurring knee injury. ",
            image: "../image/51TA5SuinyL.jpg",
            voteCount: 110
        },
        {
            title: "The Test of My Life.",
            author: " Yuvraj Singh",
            date: new Date('03/19/2013'),
            description: "Yuvraj Singh is the poster boy of Indian Cricket, the man who hit Stuart Broad (England fast bowler) for six sixes in an over in a World Twenty20 encounter against England in 2007. The ever smiling Yuvraj or “Pie-Chucker”, as he is fondly called or the bad boy of Indian Cricket is perhaps the second most loved player in Indian Cricket after the legend Sachin Tendulkar. He contributed immensely in India's World Cup win in 2011 and was adjudged the Player of the Tournament. ",
            image: "../image/Thetestofmylife.jpeg",
            voteCount: 270
        }
    ]


    $scope.upVoteBlog = function (blog) {
        blog.voteCount++;
    };

  

});    